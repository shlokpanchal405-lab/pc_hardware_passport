PC HARDWARE PASSPORT — DAY 2
ASUS TUF Gaming A15 FA506NCG

CONTENTS
Task 1 — day2_board_card.txt
  Motherboard identification, form factor, chipset disclosure, and BIOS/UEFI details.

Task 2 — cpu_socket_check.csv
  Three-CPU comparison with the required columns:
  cpu_model, socket, cores, threads, base_clock, fits_your_board

Task 3 — slot_usage_map.txt
  RAM, M.2/NVMe, SATA, and PCIe slot status with evidence and unknowns clearly identified.

Task 4 — chipset_devices.txt
  Detected platform devices and their associated buses.

IMPORTANT NOTES
- The laptop was not opened or physically disassembled.
- Unknown slot information is marked UNKNOWN rather than guessed.
- The installed CPU is recorded as soldered for the assignment's laptop-CPU rule. The CPU is already installed, so its own row is marked yes; comparison CPUs are marked no.
- ASUS's public specifications reviewed do not state a chipset model for this exact configuration.

SOURCES
ASUS model listing:
https://www.asus.com/in/laptops/for-gaming/all-series/2021-asus-tuf-gaming-a15/where-to-buy/

AMD Ryzen 7 7445HS:
https://www.amd.com/en/products/processors/laptop/ryzen/7000-series/amd-ryzen-7-7445hs.html

AMD Ryzen 7 8745HS:
https://www.amd.com/en/products/processors/laptop/ryzen/8000-series/amd-ryzen-7-8745hs.html

AMD Ryzen 5 5600X:
https://www.amd.com/en/products/processors/desktops/ryzen/5000-series/amd-ryzen-5-5600x.html
